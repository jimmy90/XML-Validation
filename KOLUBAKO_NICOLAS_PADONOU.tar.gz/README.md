XML-Validation
==============

Usage : 
ocaml Projet.ml fichierXML fichierDTD
