XML-Validation
==============

Membres du groupe:
-KOLUBAKO Tennessy
-NICOLAS Jean-Eric
-PADONOU LOUEMBET Jimmy

Usage : 
ocaml Projet.ml fichierXML fichierDTD
